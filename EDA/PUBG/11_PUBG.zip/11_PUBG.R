##installing necessary packages
install.packages(c("ggplot2", "visdat","DataExplorer","dplyr","moments"))

##importing necessary libraries

library(ggplot2)
library(visdat)
library(DataExplorer)
library(moments)


#set project file's source as working directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

##loading the dataset (csv file)
##The dataset has data about restaurant's name, location,price, ratings
pubg<- read.csv("11_PUBG.csv")
# convert to local data frame for better viewing properties
pubg <- tbl_df(pubg)

## Introduction to our data

dim(pubg) #we see that our data has 29 columns

#Checking head of loaded dataset in order to understand structure of data
head(pubg)

colnames(pubg) 
# we observe that the first 3 columns are 
#not of any analytical importance, they can be dropped.

##FEATURE ENGINEERING
pubg<-pubg[,-c(1,2,3,18)] # delete first 3 and 18th col
colnames(pubg) # the first 3 columnsare deleted.


#DATA CLEANING
#check for na values
colSums(is.na(pubg)) #display na value in each column ie no NA values in data.

##Visualization of null Values present in dataset
##the graph shows how many null values are present in the dataset
vis_miss(pubg) #the graph has about 10 percent missing values. We have to clean the data.

summary(pubg) # we can see that there 992 NA values in each col.

##removing columns with na values
##replacing na values with median of the column
pubg$assists = ifelse(is.na(pubg$assists),median(pubg$assists,na.rm = TRUE),pubg$assists)
pubg$boosts = ifelse(is.na(pubg$boosts),median(pubg$boosts,na.rm = TRUE),pubg$boosts)
pubg$damageDealt = ifelse(is.na(pubg$damageDealt),median(pubg$damageDealt,na.rm = TRUE),pubg$damageDealt)
pubg$DBNOs = ifelse(is.na(pubg$DBNOs),median(pubg$DBNOs,na.rm = TRUE),pubg$DBNOs)
pubg$headshotKills = ifelse(is.na(pubg$headshotKills),median(pubg$headshotKills,na.rm = TRUE),pubg$headshotKills)
pubg$heals = ifelse(is.na(pubg$heals),median(pubg$heals,na.rm = TRUE),pubg$heals)
pubg$killPlace = ifelse(is.na(pubg$killPlace),median(pubg$killPlace,na.rm = TRUE),pubg$killPlace)
pubg$killStreaks = ifelse(is.na(pubg$killStreaks),median(pubg$killStreaks,na.rm = TRUE),pubg$killStreaks)
pubg$killPoints = ifelse(is.na(pubg$killPoints),median(pubg$killPoints,na.rm = TRUE),pubg$killPoints)
pubg$kills = ifelse(is.na(pubg$kills),median(pubg$kills,na.rm = TRUE),pubg$kills)
pubg$longestKill = ifelse(is.na(pubg$longestKill),median(pubg$longestKill,na.rm = TRUE),pubg$longestKill)
pubg$matchDuration = ifelse(is.na(pubg$matchDuration),median(pubg$matchDuration,na.rm = TRUE),pubg$matchDuration)
pubg$matchType = ifelse(is.na(pubg$matchType),median(pubg$matchType,na.rm = TRUE),pubg$matchType)
pubg$maxPlace = ifelse(is.na(pubg$maxPlace),median(pubg$maxPlace,na.rm = TRUE),pubg$maxPlace)
pubg$rankPoints = ifelse(is.na(pubg$rankPoints),median(pubg$rankPoints,na.rm = TRUE),pubg$rankPoints)
pubg$revives = ifelse(is.na(pubg$revives),median(pubg$revives,na.rm = TRUE),pubg$revives)
pubg$rideDistance = ifelse(is.na(pubg$rideDistance),median(pubg$rideDistance,na.rm = TRUE),pubg$rideDistance)
pubg$roadKills = ifelse(is.na(pubg$roadKills),median(pubg$roadKills,na.rm = TRUE),pubg$roadKills)
pubg$swimDistance = ifelse(is.na(pubg$swimDistance),median(pubg$swimDistance,na.rm = TRUE),pubg$swimDistance)
pubg$teamKills = ifelse(is.na(pubg$teamKills),median(pubg$teamKills,na.rm = TRUE),pubg$teamKills)
pubg$vehicleDestroys = ifelse(is.na(pubg$vehicleDestroys),median(pubg$vehicleDestroys,na.rm = TRUE),pubg$vehicleDestroys)
pubg$walkDistance = ifelse(is.na(pubg$walkDistance),median(pubg$walkDistance,na.rm = TRUE),pubg$walkDistance)
pubg$weaponsAcquired = ifelse(is.na(pubg$weaponsAcquired),median(pubg$weaponsAcquired,na.rm = TRUE),pubg$weaponsAcquired)
pubg$winPoints = ifelse(is.na(pubg$winPoints),median(pubg$winPoints,na.rm = TRUE),pubg$winPoints)
pubg$winPlacePerc = ifelse(is.na(pubg$winPlacePerc),median(pubg$winPlacePerc,na.rm = TRUE),pubg$winPlacePerc)

#confirming that there are no NA values
summary(pubg)

#confirming graphically that there are no NA values
vis_miss(pubg)

#checking data types of each feature
plot_str(pubg)

plot_intro(pubg)#we can conclude that there are no missing observations.

##positive kurtosis indicates a fat-tailed distribution
kurtosis(pubg$kills)#ideal value is 3. we observe 13. therefore it is Laptokratic

skewness(pubg$kills)# this feature should have been 0. ie it is positively skewed.

##DATA VISUALISATION

#plotting a point graph of kills vs win-percentage
#alpha adds transperancy
#colouring based on match type. we observe no clusters.
ggplot(pubg, aes(x = kills, y = winPlacePerc*100, col = matchType)) +  
  geom_point(alpha = 1/2) +
  labs(title = "Winning chances based on number of kills")

#plotting a bar graph of number of kills in a match
#we observe that maximum player s have no kills. 
ggplot(pubg, aes(kills)) + 
  geom_bar(fill = "black") + 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_line(colour = "black")) + 
  labs(title = "Number of kills in a match",
       y = 'Number of matches')
  

#plotting a bar graph of headshots in a match
#we observe that maximum players have no headshots. 
ggplot(pubg, aes(headshotKills)) + 
  geom_bar(fill = 'black') + 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_line(colour = "black")) + 
  labs(title = "Number of headshots in a match",
       y = 'Number of matches')

# plot of damage dealt in a match
ggplot(pubg, aes(x = damageDealt, fill = headshotKills)) + 
  geom_histogram(binwidth = 60) + 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_line(colour = "black")) + 
  labs(title = "amount of damage dealt in a match",
       y = 'Number of matches')

## a density plot of chances of winning based on kills
ggplot(pubg, aes(x = kills, y = winPlacePerc )) + 
  geom_density_2d(alpha = 1) + 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_line(colour = "black")) + 
  labs(title = "chances of winning based on kills",
       y = 'win percent')

#a plot of match duration
#most matches are played for 1300 seconds(21 minutes)
ggplot(pubg, aes(x = matchDuration)) + 
  geom_histogram(binwidth = 30) + 
  theme(axis.line.x = element_line(colour = "black"),
        axis.line.y = element_line(colour = "black")) + 
  labs(title = "amount of damage dealt in a match",
       y = 'Number of matches')

#match duration vs winnning chances
#as we see there is no correlation between the two.
ggplot(pubg, aes(x = matchDuration, y = winPlacePerc*100, col = killPoints)) +  
  geom_point(alpha = 1/2) +
  labs(title = "match duration vs winnning chances")

#roadkill vs ride distance
# we see that maximum people ride their vehical without killing anybody.
ggplot(pubg, aes(x = rideDistance, y = roadKills*100, col = killPoints)) +  
  geom_point(alpha = 1/2) +
  labs(title = "roadkill vs ride distance")
